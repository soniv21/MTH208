It contains CSV files, scraped files and web scraping code.
