# EPL Data Analysis

Premier League is the most popular football league. It is the richest league and the most watched league in the world.

In this project, we have analysed the league over a period of 13 years i.e from 2009 to 2022.
We have made a shiny app along with a quarto report to display our analysis.

All the data files are in data folder.
The link for the presentation is in Readme.md inside presentation folder.
The code for shiny app is inside app folder.
The qmd file and html file for report is in report folder.
 
