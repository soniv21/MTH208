Link for the presentation :

https://docs.google.com/presentation/d/16U_eXthLsl2pO23RNgU-8BzuifdnTIwF/edit?usp=share_link&ouid=101104547767817664667&rtpof=true&sd=true
